# SYNTH

A personal AI chat + image generation app. Everything — the page you
see and the server that talks to image providers — lives in this one
folder and deploys as a single app.

## Folder structure

```
synth-app/
  server.js          ← the whole server: serves the app + handles image requests
  package.json
  public/
    index.html        ← the app itself
    manifest.json      ← lets you install it on your phone
    service-worker.js
    icons/
```

## Run it locally

```bash
npm install
npm start
```

Open `http://localhost:3001` in your browser. Chat works immediately.
For Image Studio, paste your OpenAI or Stability AI API key into the
field in the app — no extra config needed, since the server is right there.

## Deploy it (so you can install it on your phone)

**Render** (free tier, easiest)
1. Push this whole folder to a GitHub repo.
2. render.com → New → Web Service → connect the repo.
3. Build command: `npm install`. Start command: `npm start`.
4. Deploy. You'll get one URL, e.g. `https://synth.onrender.com`.

**Railway** works the same way — New Project → Deploy from GitHub →
it auto-detects Node and runs `npm start`.

That single URL serves everything: the chat, the image studio, and the
API behind it.

## Install it on your phone

1. Open your deployed URL in mobile Safari (iPhone) or Chrome (Android).
2. Tap Share → **Add to Home Screen**.
3. It now opens like a regular app, full screen, with its own icon.

## Notes for personal use

- Your API key is saved in your browser's local storage for convenience
  so you don't re-enter it each time. Fine on a private device only you
  use — don't do this on a shared computer.
- Chat history is also saved locally and persists between visits. Use
  the **Clear** button in the chat header to wipe it.
